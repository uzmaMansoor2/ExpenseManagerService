﻿using ExpenseManagerService.ReceiptService;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ExpenseManagerService
{
    [DataContract]
    public class CustomerVO
    {
        [DataMember]
        public int customerID { get; set; }
        [DataMember]
        public string email { get; set; }
        [DataMember]
        public string name { get; set; }
        [DataMember]
        public string surname { get; set; }
        [DataMember]
        public string password { get; set; }
        [DataMember]
        public virtual ICollection<VehicleVO> Vehicles { get; set; }
        [DataMember]
        public virtual ICollection<ReceiptVO> Receipts { get; set; }



    }
}