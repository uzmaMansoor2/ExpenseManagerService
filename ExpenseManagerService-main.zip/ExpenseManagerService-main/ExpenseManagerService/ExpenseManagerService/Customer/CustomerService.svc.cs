﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ExpenseManagerService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CustomerService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select CustomerService.svc or CustomerService.svc.cs at the Solution Explorer and start debugging.
    public class CustomerService : ICustomerService
    {
        private MySqlConnection conn;
        private MySqlCommand cmd;
        private string cmdString = "";
        public string message = "";        

        string ICustomerService.AddCustomer(Customer c)
        {
            try
            {
                conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["EMDBConnString"].ConnectionString);
               // cmdString = ("INSERT INTO Customer (email, name, surname, password) VALUES ('"+c.Email+"', '"+c.Name.ToUpper()+"', '"+c.Surname.ToUpper()+"', '"+c.Password+"');");
                cmd = new MySqlCommand(cmdString, conn);
                conn.Open();

                cmd.ExecuteNonQuery();

                conn.Close();
                message = "Customer insertion was successfull";

            }
            catch (Exception ex)
            {
                message = "Something went wrong. " + ex.ToString();
            }

            return message;
        }

        public string DeleteCustomer(string customerID)
        {
            try
            {
                conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["EMDBConnString"].ConnectionString);
                cmdString = ("DELETE FROM Customer WHERE customerID = " + customerID);
                cmd = new MySqlCommand(cmdString, conn);
                conn.Open();

                cmd.ExecuteNonQuery();

                conn.Close();
                message = "Customer: "+ customerID +", was successfully deleted";

            }
            catch (Exception ex)
            {
                message = "Something went wrong. " + ex.ToString();
            }

            return message;
        }

        public string EditCustomerEmail(string customerID, string email)
        {
            try
            {
                conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["EMDBConnString"].ConnectionString);
                cmdString = ("UPDATE Customer SET email = '"+ email +"'  WHERE customerID = " + customerID);
                cmd = new MySqlCommand(cmdString, conn);
                conn.Open();

                cmd.ExecuteNonQuery();

                conn.Close();
                message = "Customer: " + customerID + ", email was successfully updated";

            }
            catch (Exception ex)
            {
                message = "Something went wrong. " + ex.ToString();
            }

            return message;
        }
    }
    
}
