﻿using ExpenseManagerService.VehicleLogBook;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Web;

namespace ExpenseManagerService
{
    [DataContract]
    public class VehicleVO
    {
        [DataMember]
        public int vehicleID { get; set; }
        [DataMember]
        public string make { get; set; }
        [DataMember]
        public string model { get; set; }
        [DataMember]
        public short year { get; set; }
        [DataMember]
        public int engineCpacity { get; set; }
        [DataMember]
        public int odometer { get; set; }
        [DataMember]
        public int Customer_customerID { get; set; }
        [DataMember]
        public string licencePlate { get; set; }
        [DataMember]
        public virtual ICollection<TripVO> Trips { get; set; }

    }
}