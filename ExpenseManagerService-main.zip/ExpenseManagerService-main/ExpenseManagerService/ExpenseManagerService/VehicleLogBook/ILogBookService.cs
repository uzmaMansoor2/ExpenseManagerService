﻿using ExpenseManagerService.VehicleLogBook;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ExpenseManagerService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ILogBookService" in both code and config file together.
    [ServiceContract]
    public interface ILogBookService
    {
        [OperationContract]
        string addVehilce(VehicleVO vehicle);

        [OperationContract]
        VehicleVO getVehilce(int vehicleID);

        [OperationContract]
        List<VehicleVO> getAllVehilces(int customerID);

        [OperationContract]
        string updateVehicle(VehicleVO v);

        [OperationContract]
        string deleteVehicle(int vehicleID);

        [OperationContract]
        void updateOdometer(int vehicleID, int newReading);

        [OperationContract]
        string addTrip(TripVO t);

        [OperationContract]
        List<TripVO> getAllTrips(int vehicleID);

        [OperationContract]
        string updateTrip(TripVO t);

        [OperationContract]
        string deletetrip(int tripID);


    }
}
