﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;
using ExpenseManagerService.VehicleLogBook;
using System.Runtime.CompilerServices;
using System.Globalization;

namespace ExpenseManagerService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "LogBookService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select LogBookService.svc or LogBookService.svc.cs at the Solution Explorer and start debugging.
    public class LogBookService : ILogBookService
    {
        ExpenseManagerEntities5 db = new ExpenseManagerEntities5();
        public string message = "";
      
        // VEHICLE METHODS ----------------------------

        //this method adds a new vehicle into the database
        //the entire object is passsed as the parameter
        public string addVehilce(VehicleVO vehicle)
        {
            Vehicle v = new Vehicle();
            try
            {
                v.Customer_customerID = vehicle.Customer_customerID;
                v.engineCpacity = vehicle.engineCpacity;
                v.licencePlate = vehicle.licencePlate;
                v.make = vehicle.make;
                v.model = vehicle.model;
                v.odometer = vehicle.odometer;
                v.vehicleID = vehicle.vehicleID;
                v.year = vehicle.year;

                db.Vehicles.Add(v);
                db.SaveChanges();
                message = "Vehcile inserted Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        // this method returns a vehicle
        // the vehicle id is passed as a parameter and used as the search criteria
        public VehicleVO getVehilce(int vehicleID)
        {
            VehicleVO v = new VehicleVO();
            try
            {
                var vehicle = db.Vehicles.Find(vehicleID);
                v.Customer_customerID = vehicle.Customer_customerID;
                v.engineCpacity = vehicle.engineCpacity;
                v.licencePlate = vehicle.licencePlate;
                v.make = vehicle.make;
                v.model = vehicle.model;
                v.odometer = vehicle.odometer;
                v.vehicleID = vehicle.vehicleID;
                v.year = vehicle.year;

                List<TripVO> tripList = new List<TripVO>();

                foreach (var t in v.Trips)
                {
                    tripList.Add(new TripVO
                    {
                        description = t.description,
                        distanceTravelled = t.distanceTravelled,
                        endDate = t.endDate,
                        startDate = t.startDate,
                        finish = t.finish,
                        start = t.start,
                        tripID = t.tripID,
                        Vehicle_vehicleID = t.Vehicle_vehicleID,
                    });
                }
                v.Trips = tripList;

                return v;
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return null;
        }
        
        // this method returns a list of all the vehicles belonging to a certain customer
        // the customer id is passed as a parameter
        public List<VehicleVO> getAllVehilces(int customerID)
        {
            List<VehicleVO> vehicleList = new List<VehicleVO>();

            try
            {
                vehicleList = db.Vehicles.Select(v => new VehicleVO 
                {
                    Customer_customerID = v.Customer_customerID,
                    engineCpacity = v.engineCpacity,
                    licencePlate = v.licencePlate,
                    make = v.make,
                    model = v.model,
                    odometer = v.odometer,
                    vehicleID = v.vehicleID,
                    year = v.year,
                    Trips = db.Trips.Select(t => new TripVO 
                    {
                        description = t.description,
                        distanceTravelled = t.distanceTravelled,
                        endDate = t.endDate,
                        startDate = t.startDate,
                        finish = t.finish,
                        start = t.start,
                        tripID = t.tripID,
                        Vehicle_vehicleID = t.Vehicle_vehicleID
                    }).Where(t=> t.Vehicle_vehicleID == v.vehicleID).ToList()
                }).ToList();  
                
                return vehicleList;
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return null;
        }

        //this method updates a vehcile
        //the entire object is passed as a parameter
        //the vehcile id is extracted from the object and used for the update query
        public string updateVehicle(VehicleVO newVehicle)
        {
            try
            {
               var vehicle = db.Vehicles.Find(newVehicle.vehicleID);

                vehicle.Customer_customerID = newVehicle.Customer_customerID;
                vehicle.engineCpacity = newVehicle.engineCpacity;
                vehicle.licencePlate = newVehicle.licencePlate;
                vehicle.make = newVehicle.make;
                vehicle.model = newVehicle.model;
                vehicle.odometer = newVehicle.odometer;
                vehicle.vehicleID = newVehicle.vehicleID;
                vehicle.year = newVehicle.year;

                db.SaveChanges();

                message = "Vehcile updated Successfully!";

            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        //this method deletes a vehcile.
        //the vehicle id is passed as a parameter
        public string deleteVehicle(int vehicleID)
        {
            try
            {               
                db.Vehicles.Remove(db.Vehicles.Find(vehicleID));
                db.SaveChanges();
                message = "Vehcile deleted Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        //this methods updates the odometer reading of a vehicle
        //it uses the vehicle id as the search criteria 

        public void updateOdometer(int vehicleID, int newReading)
        {
            try
            {
                var v = db.Vehicles.Find(vehicleID);
                v.odometer = newReading;
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }
        }



        // TRIP METHODS ----------------------------

        //this method adds a new trip into the database
        //the entire object is passsed as the parameter
        public string addTrip(TripVO trip)
        {
            Trip t = new Trip();
            try
            {
                t.description = trip.description;
                t.distanceTravelled = trip.distanceTravelled;
                t.endDate = trip.endDate;
                t.startDate = trip.startDate;
                t.finish = trip.finish;
                t.start = trip.start;
                t.tripID = trip.tripID;
                t.Vehicle_vehicleID = trip.Vehicle_vehicleID;
                var vehicle = db.Vehicles.Find(t.Vehicle_vehicleID);
                vehicle.odometer += t.distanceTravelled;
                db.Trips.Add(t);
                db.SaveChanges();

                message = "Trip inserted Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        // this method returns a list of all the trips belonging to a certain vehicle.
        // the vehicle id is passed as a parameter
        public List<TripVO> getAllTrips(int vehicleID)
        {
            List<TripVO> tripList = new List<TripVO>();

            try
            {
                 var list = db.Trips.ToList();
                foreach (var t in list)
                {
                    tripList.Add(new TripVO
                    {
                        description = t.description,
                        distanceTravelled = t.distanceTravelled,
                        endDate = t.endDate,
                        startDate = t.startDate,
                        finish = t.finish,
                        start = t.start,
                        tripID = t.tripID,
                        Vehicle_vehicleID = t.Vehicle_vehicleID,
                    });
                }
                return tripList;
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return tripList = null;
        }

        //this method updates a trip
        //the entire object is passed as a parameter
        //the trip id is extracted from the parameter object and used for the update query
        public string updateTrip(TripVO trip)
        {
            //get trip from database
            var t = db.Trips.Find(trip.tripID);

            int  previousDistanceTravelled = db.Trips.Find(trip.tripID).distanceTravelled;

            try
            {
                //If the trip update is based on an other vehicle
                if (trip.Vehicle_vehicleID != t.Vehicle_vehicleID)
                {
                    //reset previous odometer reading for previous selected vehicle

                    //get vprevious vehicle
                    var previousVehicle = db.Vehicles.Find(t.Vehicle_vehicleID);                     

                    //subtract previous distance travelled to previous vehicle
                    previousVehicle.odometer -= previousDistanceTravelled;

                    t.description = trip.description;
                    t.distanceTravelled = trip.distanceTravelled;
                    t.endDate = trip.endDate;
                    t.startDate = trip.startDate;
                    t.finish = trip.finish;
                    t.start = trip.start;
                    t.tripID = trip.tripID;
                    t.Vehicle_vehicleID = trip.Vehicle_vehicleID;

                    // get vehicle
                    var vehicle = db.Vehicles.Find(t.Vehicle_vehicleID);
                    //add odometer reading
                    vehicle.odometer += t.distanceTravelled;
                }
                //If the trip update is based on the same vehicle
                else
                {
                    t.description = trip.description;                    
                    t.endDate = trip.endDate;
                    t.startDate = trip.startDate;
                    t.finish = trip.finish;
                    t.start = trip.start;
                    t.tripID = trip.tripID;

                    if(t.distanceTravelled < previousDistanceTravelled)
                    {
                        t.Vehicle.odometer = previousDistanceTravelled - t.distanceTravelled;
                    }
                    else if(t.distanceTravelled >= previousDistanceTravelled)
                    {
                        t.Vehicle.odometer += (t.distanceTravelled - previousDistanceTravelled);
                    }

                }           
             
                db.SaveChanges();

                message = "Trip updated Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        //this method deletes a trip.
        //the trip id is passed as a parameter
        public string deletetrip(int tripID)
        {
            try
            {
                var t = db.Trips.Find(tripID);

                var vehicle = db.Vehicles.Find(t.Vehicle_vehicleID);
                vehicle.odometer -= t.distanceTravelled;
                db.Trips.Remove(t);
                db.SaveChanges();
                message = "Trip deleted Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

      
    }
}
