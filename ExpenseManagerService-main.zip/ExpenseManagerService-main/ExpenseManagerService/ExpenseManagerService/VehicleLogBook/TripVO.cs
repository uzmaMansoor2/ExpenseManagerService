﻿using PropertyChanged;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ExpenseManagerService.VehicleLogBook
{
    [DataContract]
    public class TripVO
    {
        
        [DataMember]
        public int tripID { get; set; }
        [DataMember]
        public System.DateTime startDate { get; set; }
        [DataMember]
        public System.DateTime endDate { get; set; }
        [DataMember]
        public int distanceTravelled { get; set; }
        [DataMember]
        public string start { get; set; }
        [DataMember]
        public string finish { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public int Vehicle_vehicleID { get; set; }
        [DataMember]
        public virtual VehicleVO Vehicle { get; set; }


    }
}
