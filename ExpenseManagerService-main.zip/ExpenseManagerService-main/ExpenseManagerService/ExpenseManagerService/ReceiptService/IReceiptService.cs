﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ExpenseManagerService.ReceiptService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IReceiptService" in both code and config file together.
    [ServiceContract]
    public interface IReceiptService
    {
        [OperationContract]
        string addReceipt(ReceiptVO receipt);

        [OperationContract]
        ReceiptVO getReceipt(int receiptID);

        [OperationContract]
        List<ReceiptVO> getAllReceipt(int customerID);

        [OperationContract]
        string updateReceipt(ReceiptVO r, string newTagName);

        [OperationContract]
        string deleteReceipt(int receiptID);

        [OperationContract]
        string addTag(TagVO t);

        [OperationContract]
        List<TagVO> getAllTags(int customerID);

        [OperationContract]
        string updateTag(TagVO t);

        [OperationContract]
        string deleteTag(string tagName);
    }
}
