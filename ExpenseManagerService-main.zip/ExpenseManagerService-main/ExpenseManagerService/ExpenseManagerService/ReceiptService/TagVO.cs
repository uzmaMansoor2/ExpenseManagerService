﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ExpenseManagerService.ReceiptService
{
    [DataContract]
    public class TagVO
    {
        [DataMember]
        public string tagName { get; set; }
        [DataMember]
        public int Customer_customerID { get; set; }
        [DataMember]
        public virtual ICollection<ReceiptVO> Receipts { get; set; }
    }
}