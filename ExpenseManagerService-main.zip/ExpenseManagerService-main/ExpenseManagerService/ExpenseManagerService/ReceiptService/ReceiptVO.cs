﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ExpenseManagerService.ReceiptService

{
    [DataContract]
    public class ReceiptVO
    {
        [DataMember]
        public int receiptID { get; set; }
        [DataMember]
        public string Tag_tagName { get; set; }
        [DataMember]
        public byte[] image { get; set; }
        [DataMember]
        public double total { get; set; }
        [DataMember]
        public double tax { get; set; }
        [DataMember]
        public string ABN { get; set; }
        [DataMember]
        public System.DateTime date { get; set; }
        [DataMember]
        public string merchant { get; set; }
        [DataMember]
        public int Customer_customerID { get; set; }
        [DataMember]
        public virtual CustomerVO Customer { get; set; }
        [DataMember]
        public virtual TagVO Tag { get; set; }
    }
}