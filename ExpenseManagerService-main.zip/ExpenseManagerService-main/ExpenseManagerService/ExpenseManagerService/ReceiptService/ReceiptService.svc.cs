﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ExpenseManagerService.ReceiptService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ReceiptService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ReceiptService.svc or ReceiptService.svc.cs at the Solution Explorer and start debugging.
    public class ReceiptService : IReceiptService
    {
        ExpenseManagerEntities5 db = new ExpenseManagerEntities5();
        public string message = "";
        // RECIPT METHODS ---------------------------

        //this method adds a new receipt into the database
        //the entire object is passsed as the parameter
        public string addReceipt(ReceiptVO receipt)
        {
            Receipt r = new Receipt();
            try
            {
                r.Customer_customerID = receipt.Customer_customerID;
                r.ABN = receipt.ABN;
                r.date = receipt.date;
                r.image = receipt.image;
                r.merchant = receipt.merchant;
                r.receiptID = receipt.receiptID;
                r.Tag_tagName = receipt.Tag_tagName.ToUpper();
                r.tax = receipt.tax;
                r.total = receipt.total;

                db.Receipts.Add(r);
                db.SaveChanges();
                message = "Receipt inserted Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        //this method adds a new tag into the database
        //the entire object is passsed as the parameter
        public string addTag(TagVO tag)
        {
            Tag t = new Tag();
            try
            {
                //NOTE: Tag is converted to upper to avoid duplicate
                t.tagName = tag.tagName.ToUpper();
                t.Customer_customerID = tag.Customer_customerID;

                db.Tags.Add(t);
                db.SaveChanges();
                message = "Tag inserted Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        //this method deletes a receipt.
        //the receipt id is passed as a parameter
        public string deleteReceipt(int receiptID)
        {
            try
            {
                db.Receipts.Remove(db.Receipts.Find(receiptID));
                db.SaveChanges();
                message = "Receipt deleted Successfully!";
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        //this method deletes a tag.
        //the tag name is passed as a parameter
        public string deleteTag(string tagName)
        {
            try
            {
                var tag = db.Tags.Find(tagName);
                if (tag.Receipts.Count == 0)
                {
                    db.Tags.Remove(tag);
                    db.SaveChanges();
                    message = "Tag deleted Successfully!";
                }
                else
                {
                    message = "Tag cannot be deleted. There are existing receipts belonging to this tag!";
                }

            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        // this method returns a list of all the receipt belonging to a certain customer
        // the customer id is passed as a parameter
        public List<ReceiptVO> getAllReceipt(int customerID)
        {
            List<ReceiptVO> receiptList = new List<ReceiptVO>();

            try
            {
                var list = db.Receipts.ToList().Where(r => r.Customer_customerID == customerID);
                foreach (var r in list)
                {
                    receiptList.Add(new ReceiptVO
                    {
                        Customer_customerID = r.Customer_customerID,
                        ABN = r.ABN,
                        date = r.date,
                        image = r.image,
                        merchant = r.merchant,
                        receiptID = r.receiptID,
                        tax = r.tax,
                        total = r.total,
                        Tag_tagName = r.Tag_tagName
                    });
                }
                return receiptList;
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return receiptList = null;
        }

        // this method returns a list of all the tags belonging to a certain customer
        // the customer id is passed as a parameter
        // NOTE: this method does not return the receipts as part of the tag object.
        public List<TagVO> getAllTags(int customerID)
        {
            List<TagVO> tagList = new List<TagVO>();

            try
            {
                var list = db.Tags.ToList().Where(t => t.Customer_customerID == customerID);
                foreach (var t in list)
                {
                    tagList.Add(new TagVO
                    {
                        tagName = t.tagName

                    });
                }
                return tagList;
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return tagList = null;
        }

        public ReceiptVO getReceipt(int receiptID)
        {
            throw new NotImplementedException();
        }

        public string updateReceipt(ReceiptVO newreceipt, string newTagName)
        {
            try
            {
                var receipt = db.Receipts.Find(newreceipt.receiptID);

                receipt.Customer_customerID = newreceipt.Customer_customerID;
                receipt.ABN = newreceipt.ABN;
                receipt.date = newreceipt.date;
                receipt.image = newreceipt.image;
                receipt.merchant = newreceipt.merchant;
                receipt.receiptID = newreceipt.receiptID;
                receipt.Tag_tagName = newTagName.ToUpper();
                receipt.tax = newreceipt.tax;
                receipt.total = newreceipt.total;

                db.SaveChanges();

                message = "Receipt updated Successfully!";

            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        //NOTE: currently the update tag method is not available
        // modifying the PK could result to inconsistency throughout the database
        public string updateTag(TagVO t)
        {
            throw new NotImplementedException();
        }
    }
}
